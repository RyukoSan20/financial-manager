"""Pipeline belanja: stage, tracking, dan tautan ke transaksi

Revision ID: 20261020_shopping_pipeline
Revises: (isi dengan revision terakhirmu — jalankan `alembic heads`)
"""
import sqlalchemy as sa
from alembic import op

revision = "20261020_shopping_pipeline"
down_revision = None  # GANTI dengan revision terakhir proyekmu
branch_labels = None
depends_on = None

STAGES = "'wishlist','to_buy','ordered','shipped','received','cancelled'"


def upgrade() -> None:
    t = "shopping_items"
    op.add_column(t, sa.Column("stage", sa.String(20), nullable=False, server_default="to_buy"))
    op.add_column(t, sa.Column("position", sa.Integer(), nullable=False, server_default="0"))
    op.add_column(t, sa.Column("category_id", sa.Integer(), sa.ForeignKey("categories.id", ondelete="SET NULL")))
    op.add_column(t, sa.Column("transaction_id", sa.Integer(), sa.ForeignKey("transactions.id", ondelete="SET NULL")))
    for name, length in (("product_url", 500), ("tracking_number", 64), ("courier", 32), ("notes", 500)):
        op.add_column(t, sa.Column(name, sa.String(length)))
    op.add_column(t, sa.Column("rating", sa.SmallInteger()))
    op.add_column(t, sa.Column("purchased_at", sa.DateTime(timezone=True)))
    op.add_column(t, sa.Column("received_at", sa.DateTime(timezone=True)))

    op.create_check_constraint("ck_shopping_items_stage", t, f"stage IN ({STAGES})")
    op.create_check_constraint("ck_shopping_items_rating", t, "rating IS NULL OR rating BETWEEN 1 AND 5")
    op.create_unique_constraint("uq_shopping_items_transaction", t, ["transaction_id"])
    op.create_index("ix_shopping_items_user_stage", t, ["user_id", "stage", "position"])
    op.create_index("ix_shopping_items_user_purchased", t, ["user_id", "purchased_at"])

    # Backfill dari kolom `status` lama. Nilai di bawah hanya tebakan — cek isi
    # kolom statusmu dulu: SELECT status, count(*) FROM shopping_items GROUP BY 1;
    op.execute(
        """
        UPDATE shopping_items SET stage = 'received'
        WHERE lower(coalesce(status, '')) IN ('purchased', 'bought', 'done', 'completed')
        """
    )


def downgrade() -> None:
    t = "shopping_items"
    op.drop_index("ix_shopping_items_user_purchased", table_name=t)
    op.drop_index("ix_shopping_items_user_stage", table_name=t)
    op.drop_constraint("uq_shopping_items_transaction", t, type_="unique")
    op.drop_constraint("ck_shopping_items_rating", t, type_="check")
    op.drop_constraint("ck_shopping_items_stage", t, type_="check")
    for col in (
        "received_at", "purchased_at", "rating", "notes", "courier", "tracking_number",
        "product_url", "transaction_id", "category_id", "position", "stage",
    ):
        op.drop_column(t, col)
