"""
Model ShoppingItem — versi referensi dengan kolom pipeline.

JANGAN menimpa model yang sudah ada. Salin hanya kolom bertanda NEW ke model
milikmu, lalu sesuaikan nama tabel/kolom lama bila berbeda.

Asumsi: Base dari app.core.database; users/categories/transactions memakai
primary key Integer; uang disimpan sebagai integer rupiah.
"""
from sqlalchemy import (
    BigInteger, CheckConstraint, Column, DateTime, ForeignKey, Index, Integer, SmallInteger, String,
)
from sqlalchemy.sql import func

from app.core.database import Base


class ShoppingItem(Base):
    __tablename__ = "shopping_items"

    # --- kolom lama (sesuaikan dengan modelmu) ---
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(200), nullable=False)
    quantity = Column(Integer, nullable=False, default=1)
    price = Column(BigInteger)  # harga satuan rencana, rupiah. Kalau sekarang Float, migrasikan ke BigInteger
    marketplace = Column(String(50))
    status = Column(String(20))  # lama; dipertahankan selama masa transisi
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)

    # --- NEW ---
    stage = Column(String(20), nullable=False, default="to_buy", server_default="to_buy")
    position = Column(Integer, nullable=False, default=0, server_default="0")
    category_id = Column(Integer, ForeignKey("categories.id", ondelete="SET NULL"))
    transaction_id = Column(Integer, ForeignKey("transactions.id", ondelete="SET NULL"), unique=True)
    product_url = Column(String(500))
    tracking_number = Column(String(64))
    courier = Column(String(32))
    rating = Column(SmallInteger)
    notes = Column(String(500))
    purchased_at = Column(DateTime(timezone=True))
    received_at = Column(DateTime(timezone=True))

    __table_args__ = (
        CheckConstraint(
            "stage IN ('wishlist','to_buy','ordered','shipped','received','cancelled')",
            name="ck_shopping_items_stage",
        ),
        CheckConstraint("rating IS NULL OR rating BETWEEN 1 AND 5", name="ck_shopping_items_rating"),
        Index("ix_shopping_items_user_stage", "user_id", "stage", "position"),
        Index("ix_shopping_items_user_purchased", "user_id", "purchased_at"),
    )
