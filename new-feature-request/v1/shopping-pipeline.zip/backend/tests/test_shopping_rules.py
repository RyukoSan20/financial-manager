"""Tes aturan pipeline (tanpa DB). Jalankan: pytest backend/tests/test_shopping_rules.py"""
from datetime import date, datetime

import pytest

from app.services import shopping_rules as r


def test_every_stage_has_rules_and_valid_targets():
    assert set(r.TRANSITIONS) == set(r.STAGE_ORDER)
    for src, targets in r.TRANSITIONS.items():
        assert targets <= set(r.STAGE_ORDER), src
        assert src not in targets, f"{src} tidak boleh menuju dirinya sendiri"


def test_received_is_final():
    assert r.allowed_next("received") == []


def test_ordered_only_reachable_from_planning_stages():
    sources = {s for s, t in r.TRANSITIONS.items() if "ordered" in t}
    assert sources == {"wishlist", "to_buy"}


def test_cancelled_can_be_reopened_but_not_jump_to_paid():
    assert r.can_move("cancelled", "to_buy")
    assert not r.can_move("cancelled", "ordered")
    assert not r.can_move("cancelled", "received")


def test_allowed_next_follows_board_order():
    assert r.allowed_next("to_buy") == ["wishlist", "ordered", "cancelled"]


def test_month_bounds_regular_and_december_rollover():
    lo, hi = r.month_bounds("2026-10")
    assert (lo.month, lo.day, hi.month, hi.day) == (10, 1, 11, 1)
    lo, hi = r.month_bounds("2026-12")
    assert (hi.year, hi.month, hi.day) == (2027, 1, 1)
    assert lo.utcoffset().total_seconds() == 7 * 3600


@pytest.mark.parametrize("bad", ["2026-13", "2026-00", "abc", "2026"])
def test_month_bounds_rejects_bad_input(bad):
    with pytest.raises(ValueError):
        r.month_bounds(bad)


def test_day_range_includes_the_end_day():
    lo, hi = r.day_range_bounds(date(2026, 10, 1), date(2026, 10, 31))
    assert hi == datetime(2026, 11, 1, tzinfo=r.WIB)
    last_second = datetime(2026, 10, 31, 23, 59, 59, tzinfo=r.WIB)
    assert lo <= last_second < hi


def test_rollup_sums_counts_and_sorts_desc():
    rows = r.rollup([("Makanan", 10_000), ("Belanja", 50_000), ("Makanan", 15_000)])
    assert rows == [
        {"label": "Belanja", "count": 1, "total": 50_000},
        {"label": "Makanan", "count": 2, "total": 25_000},
    ]
    assert r.rollup([]) == []
